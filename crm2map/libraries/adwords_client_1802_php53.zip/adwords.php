<?php

define('VENDOR_NAME', 'adwords_client_1802_php53');
require __DIR__ . '/' . VENDOR_NAME . '/vendor/autoload.php';
use Google\AdsApi\AdWords\AdWordsServices;
use Google\AdsApi\AdWords\AdWordsSession;
use Google\AdsApi\AdWords\AdWordsSessionBuilder;
use Google\AdsApi\AdWords\v201802\cm\ReportDefinitionReportType;
use Google\AdsApi\AdWords\v201802\cm\ReportDefinitionService;
use Google\AdsApi\AdWords\v201802\cm\OrderBy;
use Google\AdsApi\AdWords\v201802\cm\Paging;
use Google\AdsApi\AdWords\v201802\cm\Selector;
use Google\AdsApi\AdWords\v201802\cm\SortOrder;
use Google\AdsApi\AdWords\v201802\mcm\ManagedCustomer;
use Google\AdsApi\AdWords\v201802\mcm\ManagedCustomerService;
use Google\AdsApi\AdWords\v201802\mcm\Customer;
use Google\AdsApi\AdWords\v201802\mcm\CustomerService;
use Google\AdsApi\AdWords\Reporting\v201802\DownloadFormat;
use Google\AdsApi\AdWords\Reporting\v201802\ReportDefinition;
use Google\AdsApi\AdWords\Reporting\v201802\ReportDefinitionDateRangeType;
use Google\AdsApi\AdWords\Reporting\v201802\ReportDownloader;
use Google\AdsApi\AdWords\ReportSettingsBuilder;
use Google\AdsApi\AdWords\v201802\cm\Predicate;
use Google\AdsApi\AdWords\v201802\cm\PredicateOperator;
use Google\AdsApi\AdWords\v201802\cm\DateRange;
use Google\AdsApi\AdWords\v201802\cm\CampaignService;
use Google\AdsApi\AdWords\v201802\cm\AdGroupService;
use Google\AdsApi\Common\OAuth2TokenBuilder;
use Google\AdsApi\Common\SoapSettingsBuilder;


define('CustomerService__class','Google\AdsApi\AdWords\v201802\mcm\CustomerService');
define('CampaignService__class','Google\AdsApi\AdWords\v201802\cm\CampaignService');
define('ManagedCustomerService__class','Google\AdsApi\AdWords\v201802\mcm\ManagedCustomerService');
define('AdGroupService__class','Google\AdsApi\AdWords\v201802\cm\AdGroupService');
//*********************************************************************

function getCampaignData($params=array()) {
// #1R

	$adWordsServices = new AdWordsServices();
	$session = getSession($params['customer']);



	/*
        $user = getAdwordsUser();
    //	print_r($user);exit;
        $user->SetClientCustomerId($params['customer']);
    */
	$dateRange = sprintf('%d,%d', $params['start'], $params['end']);
	$id=0;
	switch ($params['report']) {
		case "cost":
			$reportQuery = 'SELECT AdGroupId, AdGroupName, Cost FROM ADGROUP_PERFORMANCE_REPORT '
				. 'WHERE Cost>0 '//AdGroupId IN ['.implode(",",$params['campaigns']).'] '
				. 'DURING ' . $dateRange;//. 'ORDER BY HourOfDay DESC LIMIT 0,1' CampaignId IN [' . $campaignId . '] AND
			$fields=array('id','group',$params['report']);
			break;
		case "url":
			$reportQuery = 'SELECT AdGroupId, AdGroupName, EffectiveFinalUrl FROM FINAL_URL_REPORT '
//		. 'WHERE AdGroupId IN ['.implode(",",$params['campaigns']).'] '
				. 'DURING ' . $dateRange;//. 'ORDER BY HourOfDay DESC LIMIT 0,1' CampaignId IN [' . $campaignId . '] AND
			$fields=array('id','group',$params['report']);
			break;
		case "location"://AdGroupId,
			$reportQuery = 'SELECT Cost, MostSpecificCriteriaId, CountryCriteriaId, RegionCriteriaId FROM GEO_PERFORMANCE_REPORT '
				.' WHERE IsTargetingLocation IN [true,false] AND LocationType = LOCATION_OF_PRESENCE'
//        . 'WHERE CampaignName IN ["Click2Call"] '
				. ' DURING ' . $dateRange;//. 'ORDER BY HourOfDay DESC LIMIT 0,1' CampaignId IN [' . $campaignId . '] AND
			$fields=array(/* 'group', */'cost', $params['report'],'country','region');
			$id=-1;
			break;

	}

	try {
		// Download report as a string.
		$reportDownloader = new ReportDownloader($session);
		// Optional: If you need to adjust report settings just for this one
		// request, you can create and supply the settings override here. Otherwise,
		// default values from the configuration file (adsapi_php.ini) are used.
		$reportSettingsOverride = ($tmp = new ReportSettingsBuilder()) ? $tmp->includeZeroImpressions(false)->build() : $tmp->includeZeroImpressions(false)->build();
		$reportDownloadResult = $reportDownloader->downloadReportWithAwql($reportQuery, DownloadFormat::CSV, $reportSettingsOverride);
//		print_r(parse_report($reportDownloadResult->getAsString(),$fields,$id));exit;
		return parse_report($reportDownloadResult->getAsString(),$fields,$id);
	} catch (Exception $e) {
		$res['error'] = $e->getMessage();
		$res['body'] = $e->getMessage();
		vendor_log('getCampaignData report error: (getCampaignData) -
			' . $res['body'], 'external');
	}
	/*
        // Set additional options.
        $options = array('version' => ADWORDS_VERSION);

        // Download report.

        //params
        $ru=new ReportUtils();
    //	echo $reportQuery;exit;
        return parse_report($ru->DownloadReportWithAwql($reportQuery, NULL, $user, 'CSV',$options),$fields,$id);
    */
}

function parse_report($body,$fields=array(),$id=0) {
	$items=array();
	$lines=explode("\n",$body);
	if (sizeof($lines)>3) {
		for ($i = 2; $i < sizeof($lines) - 1; $i++) {
			//						echo $lines[2];
			$tmp = str_getcsv($lines[$i], ",", '"');
			if ($id>=0) {
				$items[$tmp[$id]]=array();
				foreach ($fields as $j=>$fld)
					$items[$tmp[$id]][$fld]=$tmp[$j];
			} else {
				$itm=array();
				foreach ($fields as $j=>$fld)
					$itm[$fld]=$tmp[$j];
				$items[]=$itm;
			}
//			exit;
		}
	}
	return $items;
}

function getSession($cid = 0)
{
	$oauth2Info=array(
			'client_id' => "958235329474-bmtqdeif1fci3k09iki7b44gpqak4ebb.apps.googleusercontent.com",
			'client_secret' => "I2H8yJnKDFWXPOC-6881EbJL",
			'refresh_token' => "1/GEOJTc5qQKULJNB_0TCv3FC0AGwMqCSQo5HCHBiuN4316hrcbqUzKagYRr18IPiX",
			'developer_token' => "T8bWMd4K0QZ_qD61A8jURg",
			'user_agent' => "Call Scorer");

//    $oauth2Info = array('client_id' => $conn['clientId'], 'client_secret' => $conn['clientSecret'], 'refresh_token' => $conn['refreshToken']);
//	echo "innnnnnnnnnn";exit;

    $fn = dirname(__FILE__) . '/' . VENDOR_NAME . '/adsapi_php.ini';
    $oAuth2Credential = ($tmp = new OAuth2TokenBuilder()) ? $tmp->fromFile($fn)->withClientId($oauth2Info['client_id'])->withClientSecret($oauth2Info['client_secret'])->withRefreshToken($oauth2Info['refresh_token'])->build() : $tmp->fromFile($fn)->withClientId($oauth2Info['client_id'])->withClientSecret($oauth2Info['client_secret'])->withRefreshToken($oauth2Info['refresh_token'])->build();

    // Construct an API session configured from a properties file and the
    // OAuth2 credentials above.
    $soapSettings = ($tmp = new SoapSettingsBuilder()) ? $tmp->disableSslVerify()->build() : $tmp->disableSslVerify()->build();
    if ($cid > 0) {
        $session = ($tmp = new AdWordsSessionBuilder()) ? $tmp->fromFile($fn)->withDeveloperToken($oauth2Info['developer_token'])->withUserAgent($oauth2Info['user_agent'])->withClientCustomerId($cid)->withSoapSettings($soapSettings)->withOAuth2Credential($oAuth2Credential)->build() : $tmp->fromFile($fn)->withDeveloperToken($oauth2Info['developer_token'])->withUserAgent($oauth2Info['user_agent'])->withClientCustomerId($cid)->withSoapSettings($soapSettings)->withOAuth2Credential($oAuth2Credential)->build();
    } else {
        $session = ($tmp = new AdWordsSessionBuilder()) ? $tmp->fromFile($fn)->withDeveloperToken($oauth2Info['developer_token'])->withUserAgent($oauth2Info['user_agent'])->withSoapSettings($soapSettings)->withOAuth2Credential($oAuth2Credential)->build() : $tmp->fromFile($fn)->withDeveloperToken($oauth2Info['developer_token'])->withUserAgent($oauth2Info['user_agent'])->withSoapSettings($soapSettings)->withOAuth2Credential($oAuth2Credential)->build();
    }

    return $session;
}

